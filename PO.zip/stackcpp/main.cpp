#include <iostream>
#include "stack.h"

using namespace std;

int main()
{
    Stack s1;
    int i = 0;
    for(i = 0; i < 20; ++i)
    {
        s1.push(i);
    }
    for(i = 0; i < 30; ++i)
    {
        std::cout << s1.pop() << "\n";
        //std::cout << s1.getSize() << "\n";
    }
    return 0;
}
