#include "stack.h"


Stack::Stack()
{
    top = 0;
    currentSize = 10;
    maxSize = 160;
    content = (int *)malloc(currentSize * sizeof(int));
}

bool Stack::push(int x)
{
    if(top == currentSize)
    {
        if(currentSize < maxSize)
        {
            currentSize <<= 1;
            content = (int *)realloc(content, currentSize * sizeof(int));
        }
        else return false;
    }
    *(content + top) = x;
    ++top;
    return true;
}

bool Stack::isEmpty() const
{
    return top == 0;
}

int Stack::pop(bool *check)
{
    if(isEmpty())
    {
        if(check) *check = false;
        return 0;
    }
    --top;
    int toReturn = *(content + top);
    if(top < (currentSize / 2) && currentSize > 10)
    {

        std::cout << "free\n";
        currentSize /= 2;
        content = (int *)realloc(content, currentSize);
    }
    return toReturn;
}

int Stack::getSize()
{
    return currentSize;
}

void Stack::clear()
{
    top = 0;
    currentSize = 10;
    content = (int *)realloc(content, currentSize);
}

Stack::~Stack()
{
    free(content);
}
