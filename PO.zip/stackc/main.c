#include <stdlib.h>
#include <stdio.h>
#include "stack.h"

int main()
{
    stack s1;
    stackInit(&s1);
    int i;
    for(i = 0; i < 160; ++i)
    {
        push(&s1, i);
    }
    // clear(&s1);
    while (!isEmpty(&s1))
    {
        printf("%d\n", pop(&s1));
    }
    stackDestroy(&s1);
    return 0;
}
