
#include <stdbool.h>
typedef struct stack stack;

struct stack
{
    int top;
    int currentSize;
    int maxSize;
    int *block;
};


bool stackInit(stack *ptr);
void stackDestroy(stack *ptr);
bool push(stack *ptr, int n);
int size(stack *ptr);
bool isEmpty(stack *ptr);
int pop(stack *ptr);
void clear(stack *ptr);
