#include <stdlib.h>
#include <stdio.h>
#include "stack.h"

int main()
{
    stack s1;
    stackInit(&s1);
    stackDestroy(&s1);
    return 0;
}
