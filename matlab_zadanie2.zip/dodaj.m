
function [x] = dodaj (input1, input2)
  if(isscalar(input1)) 
    maxsize = size(input2);
    for i=1:maxsize(1)
      for j=1:maxsize(2)
        x(i, j) = input1 + input2(i, j);
      end
    end
    return
  elseif(isscalar(input2))
    maxsize = size(input1);    
    for i=1:maxsize(1)
      for j=1:maxsize(2)
        x(i, j) = input1(i, j) + input2;
      end
    end
    return
  end


  if((size(input1) ~= size(input2)) && ~isscalar(input1) && ~isscalar(input2))
    disp('wrong sizes')
    return
  end

  maxsize = size(input1);
  x = zeros(maxsize);
  for i=1:maxsize(1)
    for j=1:maxsize(2)
      x(i, j) = input1(i, j) + input2(i, j);
    end
  end

endfunction
