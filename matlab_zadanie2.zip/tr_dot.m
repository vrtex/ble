function [t] = tr_dot (a)
  t = zeros(size(a, 2), size(a, 1)) + i*zeros(size(a, 2), size(a, 1));
  for r = 1:size(t, 1)
    for j = 1:size(t, 2)
      t(r, j) = a(j, r);
    end
  end
  
endfunction
