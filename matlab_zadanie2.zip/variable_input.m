function [x] = variable_input (type, varargin)    
  switch type
    case '+'
      if(nargin == 2)
        x = varargin{1};
        return
      end
      msize = size(varargin{1});
      x = zeros(msize);
      for u = 1:(nargin - 1)
        if(size(varargin{u}) == msize)
          x += varargin{u}
        end
      end
      
    case '*'
      disp('mnozenie')
      if(nargin == 2)
        x = varargin{1};
        return;
      end
      x = varargin{1};
      for u = 2:(nargin - 1)
        if(size(x, 2) == size(varargin{u}, 1))
          x = x * varargin{u};
        end
      end
    case '.*'
      if(nargin == 2)
        x = varargin{1};
        return;
      end
      msize = size(varargin{1});
      x = varargin{1};
      for u = 2:(nargin - 1)
        if(size(varargin{u}) == msize)
          x = x .* varargin{u};
        end
      end
      
    otherwise
  end
  
endfunction
