function [varargout] = batch_transpose (varargin)
  varargout = varargin;
  for a = 1:nargin
    choice = 0;
    if(iscomplex(varargin{a}))
      fprintf("complex matrix: \n\n")
      disp(varargin{a})
      fprintf("\n\n0: normal transpose\n anything else: dot transpose\n");
      choice = input(" ");
    end
    
    if(choice == 0)
      varargout{a} = tr(varargin{a});
    else
      varargout{a} = tr_dot(varargin{a});
    end
  end
  
endfunction
