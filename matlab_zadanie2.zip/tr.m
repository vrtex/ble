function [t] = tr (a)
  t = zeros(size(a, 2), size(a, 1)) + i*zeros(size(a, 2), size(a, 1));
  for r = 1:size(t, 1)
    for j = 1:size(t, 2)
      t(r, j) = real(a(j, r));
      t(r, j) -= (imag(a(j, r)) * i);
    end
  end
  
endfunction
