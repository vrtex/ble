function [x] = power (m, s)
  if(size(m, 1) ~= size(m, 2) || s < 0)
    disp('wrong size or exponent less than 0')
    return
  end
  if(s == 0)
    x = eye(size(m))
    return
  end
  x = m;
  for a = 1:s-1
    x = mnoz(x, m);
  end
  
endfunction
