choice = menu("Wybierz operacje: ", "dodaj", "mnoz", "mnoz.", "transpozycja", "transpozycja.", "potega", "potega.");

switch choice
  case 1
    m1 = input('podaj macierz a: ');
    m2 = input('podaj macierz b: ');
    disp('wynik i czas iteracyjnie: ')
    tic
    dodaj(m1, m2)
    toc
    disp('czas normalnie: ')
    tic
    m1 + m2;
    toc
    if(m1 + m2 == dodaj(m1, m2))
      disp('dzialanie poprawne')
    end
  case 2
    m1 = input('podaj macierz a: ');
    m2 = input('podaj macierz b: ');
    disp('wynik i czas iteracyjnie: ')
    tic
    mnoz(m1, m2)
    toc
    disp('czas normalnie: ')
    tic
    m1 * m2;
    toc
    if(m1 * m2 == mnoz(m1, m2))
      disp('dzialanie poprawne')
    end
  case 3
    m1 = input('podaj macierz a: ');
    m2 = input('podaj macierz b: ');
    disp('wynik i czas iteracyjnie: ')
    tic
    mnoz_dot(m1, m2)
    toc
    disp('czas normalnie: ')
    tic
    m1 .* m2;
    toc
    if(m1 .* m2 == mnoz_dot(m1, m2))
      disp('dzialanie poprawne')
    end
  case 4
    m1 = input('podaj macierz do transpozycji: ');
    disp('wynik i czas iteracyjnie: ')
    tic
    tr(m1)
    toc
    disp('czas normalnie: ')
    tic
    m1'
    toc
    if(tr(m1) == m1')
      disp('dzialanie poprawne')
    end
  case 5
    m1 = input('podaj macierz do transpozycji: ');
    disp('wynik i czas iteracyjnie: ')
    tic
    tr_dot(m1)
    toc
    disp('czas normalnie: ')
    tic
    m1.'
    toc
    if(tr_dot(m1) == m1.')
      disp('dzialanie poprawne')
    end
  case 6
    m1 = input('podaj macierz a: ');
    m2 = input('podaj wykladnik: ');
    disp('wynik i czas iteracyjnie: ')
    tic
    power(m1, m2)
    toc
    disp('czas normalnie: ')
    tic
    m1 ^ m2;
    toc
    if(m1 ^ m2 == power(m1, m2))
      disp('dzialanie poprawne')
    end
  case 7
    m1 = input('podaj macierz a: ');
    m2 = input('podaj wykladnik: ');
    disp('wynik i czas iteracyjnie: ')
    tic
    power_dot(m1, m2)
    toc
    disp('czas normalnie: ')
    tic
    m1 .^ m2;
    toc
    if(m1 .^ m2 == power_dot(m1, m2))
      disp('dzialanie poprawne')
    end
    otherwise
    
  end
  