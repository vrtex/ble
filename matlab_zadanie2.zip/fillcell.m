function [s] = fillcell (a, b, y, x)
  s = 0;
  for i=1:size(a, 2)
    s += a(y, i) * b(i, x);
  end
  
endfunction
