function [x] = mnozskal (m, s)
  x = zeros(size(m, 1), size(m, 2));
  for i=1:size(m, 1)
    for j=1:size(m, 2)
      x(i, j) = m(i, j) * s;
    end
  end
  
endfunction
