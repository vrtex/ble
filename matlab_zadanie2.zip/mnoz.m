function [x] = mnoz (a, b)
  if(isscalar(a))
    x = mnozskal(b, a);
    return
  elseif(isscalar(b))
    x = mnozskal(a, b);
    return
  end
  x = zeros(2);
  if(size(a, 2) ~= size(b, 1))
    disp('wrong size')
    return
  end
  x = zeros(size(a, 1), size(b, 2));
  for i=1:size(x, 1)
    for j = 1:size(x, 2)
      x(i, j) = fillcell(a, b, i, j);
    end
  end
endfunction
