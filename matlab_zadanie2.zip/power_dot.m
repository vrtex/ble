function [x] = power_dot (m, s)
  x = zeros(size(m));
  for a = 1:size(m, 1)
    for b = 1:size(m, 2)
      x(a, b) = m(a, b) ^ s;
    end
  end
  
endfunction
