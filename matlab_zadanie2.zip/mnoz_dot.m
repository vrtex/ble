function [x] = mnoz_dot (a, b)
  if(isscalar(a))
    x = mnozskal(b, a);
    return
  elseif(isscalar(b))
    x = mnozskal(a, b);
    return
  end
  
  if(size(a) ~= size(b))
    disp('wrong size')
    return
  end
  x = zeros(size(a));
  for k = 1:size(a, 1)
    for l = 1:size(a, 2)
      x(k, l) = a(k, l) * b(k, l);
    end
  end
  
endfunction
