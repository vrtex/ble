package omgrofl.interpreter;

public interface Parameter {
    Object evaluate();
}
