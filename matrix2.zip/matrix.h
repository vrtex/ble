#ifndef MATRIX_H
#define MATRIX_H

#include <iostream>
#include <fstream>
#include <algorithm>

class bad_index{};
class bad_size{};
class makes_no_sense{};

class Matrix
{
private:
    struct MatrixContent
    {
        MatrixContent(int x, int y);
        MatrixContent(MatrixContent *other);
        ~MatrixContent();
        int n, x, y;
        double *content;
    };
    struct MatrixRef
    {
        MatrixRef(Matrix *parent);
        void setContent(MatrixContent *block);
        operator double();
        MatrixRef & operator=(double newValue);
        int order;
        MatrixContent *block;
        Matrix *parent;
    };
public:
    Matrix();
    Matrix(int x);
    Matrix(int x, int y);
    Matrix(Matrix &other);
    MatrixRef & operator()(int x, int y);
    Matrix & operator=(const Matrix &other);
    bool operator==(Matrix &other);
    Matrix operator+(Matrix &other);
    Matrix & operator+=(Matrix &other);
    Matrix operator-(Matrix &other);
    Matrix & operator-=(Matrix &other);
    Matrix operator*(Matrix &other);
    Matrix & operator*=(Matrix &other);
    friend std::ostream & operator<<(std::ostream &outStream, Matrix &m);
    friend std::ifstream & operator>>(std::ifstream &inputFile, Matrix &m);
    ~Matrix();
private:
    void init(int x, int y);
    void detach();
    void splitContent();
    double calculateCellSum(Matrix &other, int x, int y);
    MatrixContent *content;
    MatrixRef currentElement;
    int xSize, ySize;
};

#endif
