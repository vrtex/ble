#include "matrix.h"

//--------------------------------------------------------

Matrix::Matrix() :
    currentElement(this)
{
    content = nullptr;
    xSize = 0;
    ySize = 0;
}

Matrix::Matrix(int x) :
    currentElement(this)
{
    if(x <= 0) throw makes_no_sense();
    init(x, x);
}

Matrix::Matrix(int x, int y) :
    currentElement(this)
{
    if(x <= 0 || y <= 0) throw makes_no_sense();
    init(x, y);
}

Matrix::Matrix(Matrix &other) :
    currentElement(this)
{
    content = other.content;
    ++content->n;
    xSize = other.xSize;
    ySize = other.ySize;
    currentElement.setContent(content);
}

void Matrix::init(int x, int y)
{
    content = new Matrix::MatrixContent(x, y);
    xSize = x;
    ySize = y;
    for(int i = 0; i < x * y; ++i)
    {
        *(content->content + i) = 0;
    }
    currentElement.setContent(content);
}


void Matrix::detach()
{
    if(content == nullptr)
    {
        return;
    }
    content->n -= 1;
    if(content->n == 0)
    {
        delete content;
    }
    else
    content = nullptr;
    currentElement.setContent(nullptr);
}

void Matrix::splitContent()
{
    if(content && content->n == 1)
    {
        return;
    }
    MatrixContent *newBlock;
    if(content)
    {
        newBlock = new MatrixContent(content);
        detach();
    }
    else
    {
        newBlock = new MatrixContent(xSize, ySize);
    }
    content = newBlock;
    currentElement.setContent(content);
}


Matrix::MatrixRef & Matrix::operator()(int x, int y)
{
    if(x < 0 || y < 0 || x >= xSize || y >= ySize) throw bad_index();
    currentElement.order = x + xSize * y;
    return currentElement;
}

Matrix & Matrix::operator=(const Matrix &other)
{
    if(this == &other)
        return *this;
    detach();

    xSize = other.xSize;
    ySize = other.ySize;
    content = other.content;
    ++content->n;
    currentElement.setContent(content);
    return *this;
}

bool Matrix::operator==(Matrix &other)
{
    if(xSize != other.xSize || ySize != other.ySize) return false;
    for(int y = 0; y < ySize; ++y)
    {
        for(int x = 0; x < xSize; ++x)
        {
            if((double)(*this)(x, y) != (double)other(x, y)) return false;
        }
    }
    return true;
}

Matrix Matrix::operator+(Matrix &other)
{
    if(xSize != other.xSize || ySize != other.ySize) throw bad_size();
    Matrix toReturn(xSize, ySize);
    for(int y = 0; y < ySize; ++y)
    {
        for(int x = 0; x < xSize; ++x)
        {
            toReturn(x, y) = (*this)(x, y) + other(x, y);;
        }
    }
    return toReturn;
}

Matrix & Matrix::operator+=(Matrix &other)
{
    if(xSize != other.xSize || ySize != other.ySize) throw bad_size();
    *this = *this + other;
    return *this;
}

Matrix Matrix::operator-(Matrix &other)
{
    if(xSize != other.xSize || ySize != other.ySize) throw bad_size();
    Matrix toReturn(xSize, ySize);
    for(int y = 0; y < ySize; ++y)
    {
        for(int x = 0; x < xSize; ++x)
        {
            toReturn(x, y) = (*this)(x, y) - other(x, y);;
        }
    }
    return toReturn;
}

Matrix & Matrix::operator-=(Matrix &other)
{
    if(xSize != other.xSize || ySize != other.ySize) throw bad_size();
    *this = *this - other;
    return *this;
}

Matrix Matrix::operator*(Matrix &other)
{
    if(xSize != other.ySize || ySize != other.xSize) throw bad_size();
    Matrix toReturn(other.xSize, ySize);
    for(int y = 0; y < toReturn.ySize; ++y)
    {
        for(int x = 0; x < toReturn.xSize; ++x)
        {
            toReturn(x, y) = calculateCellSum(other, x, y);
        }
    }
    return toReturn;
}

Matrix & Matrix::operator*=(Matrix &other)
{
    (*this) = (*this) * other;
    return (*this);
}

std::ostream & operator<<(std::ostream &outStream, Matrix &m)
{
    if(!m.content)
    {
        outStream << "<empty matrix>\n";
        return outStream;
    }
    for(int y = 0; y < m.ySize; ++y)
    {
        for(int x = 0; x < m.xSize; ++x)
        {
            outStream << *(m.content->content + x + y * m.xSize) << "\t";
        }
        outStream << "\n";
    }
    outStream << "\n";
    return outStream;
}

std::ifstream & operator>>(std::ifstream &inputFile, Matrix &m)
{
    //if(m.content) m.detach();
    int xSize, ySize;
    inputFile >> xSize >> ySize;
    m = Matrix(xSize, ySize);
    // m.xSize = xSize;
    // m.ySize = ySize;
    std::cout << "xSize= " << xSize << "\n";
    std::cout << "ySize= " << ySize << "\n";
    for(int y = 0; y < ySize; ++y)
    {
        for(int x = 0; x < xSize; ++x)
        {
            double temp;
            inputFile >> temp;
            m(x, y) = temp;
        }
    }
    return inputFile;
}


double Matrix::calculateCellSum(Matrix &other, int x, int y)
{
    double sum = 0.0;
    for(int p = 0; p < xSize; ++p)
    {
        sum += (*this)(p, y) * other(x, p);
    }
    return sum;
}



Matrix::~Matrix()
{
    detach();
}

//--------------------------------------------------------

Matrix::MatrixContent::MatrixContent(int x, int y)
{
    n = 1;
    this->x = x;
    this->y = y;
    content = new double[x * y];
}

Matrix::MatrixContent::MatrixContent(MatrixContent *other)
{
    x = other->x;
    y = other->y;
    n = 1;

    content = new double[x * y];
    std::copy(other->content, other->content + other->x * other->y, content);
}

Matrix::MatrixContent::~MatrixContent()
{
    delete[] content;
}


//------------------------------------------------------


Matrix::MatrixRef::MatrixRef(Matrix *parent) :
    parent(parent)
{
    block = nullptr;
}

void Matrix::MatrixRef::setContent(MatrixContent *block)
{
    this->block = block;
}

Matrix::MatrixRef::operator double()
{
    return *(block->content + order);
}

Matrix::MatrixRef & Matrix::MatrixRef::operator=(double newValue)
{
    parent->splitContent();
    *(block->content + order) = newValue;
    return *this;
}
