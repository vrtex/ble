#include <iostream>
#include <fstream>
#include "matrix.h"

int main()
{
    Matrix m1, m2, m3;
    std::ifstream inFile;
    inFile.open("aaa.txt");
    inFile >> m1;
    inFile.close();
    std::cout << m1;
    inFile.open("bbb.txt");
    inFile >> m2;
    inFile.close();
    std::cout << m2;
    m3 = m1 * m2;
    std::cout << m3;
    return 0;
}
