#ifndef STACK_H
#define STACK_H

#include <cstdlib>
#include <iostream>
#include <algorithm>

class Stack
{
public:
    Stack();
    bool push(int x);
    bool isEmpty() const;
    int pop(bool *check = nullptr);
    int getSize();
    void clear();
    ~Stack();
private:
    int maxSize;
    int currentSize;
    int top;
    int *content;
};

#endif
