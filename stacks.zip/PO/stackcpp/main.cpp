#include <iostream>
#include "stack.h"

int main()
{
    Stack s1;
    int i = 0;
    for(i = 0; i < 50; ++i)
    {
        s1.push(i);
    }
    while (!s1.isEmpty())
    {
        std::cout << s1.pop() << std::endl;
    }
    return 0;
}
