#include "stack.h"


Stack::Stack()
{
    top = 0;
    currentSize = 10;
    maxSize = 160;
    content = new int [currentSize];
}

bool Stack::push(int x)
{
    if(top == currentSize)
    {
        if(currentSize < maxSize)
        {
            currentSize <<= 1;
            int *newContent = new int [currentSize];
            std::copy(content, content + top, newContent);
            delete [] content;
            content = newContent;
        }
        else return false;
    }
    *(content + top) = x;
    ++top;
    return true;
}

bool Stack::isEmpty() const
{
    return top == 0;
}

int Stack::pop(bool *check)
{
    if(isEmpty())
    {
        if(check) *check = false;
        return 0;
    }
    --top;
    int toReturn = *(content + top);
    if(top < (currentSize / 2) && currentSize > 10)
    {
        currentSize >>= 1;
        int *newContent = new int [currentSize];
        std::copy(content, content + top, newContent);
        delete [] content;
        content = newContent;
    }
    return toReturn;
}

int Stack::getSize()
{
    return currentSize;
}

void Stack::clear()
{
    top = 0;
    currentSize = 10;
    delete [] content;
    content = new int [currentSize];

}

Stack::~Stack()
{
    delete [] content;
}
