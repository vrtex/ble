#include "stack.h"
#include <stdlib.h>



bool stackInit(stack *ptr)
{
    ptr->maxSize = 160;
    ptr->currentSize = 10;
    ptr->top = 0;
    ptr->block = (int *)malloc(ptr->currentSize * sizeof(int));
    if(ptr->block) return true;
    return false;
}

void stackDestroy(stack *ptr)
{
    free(ptr->block);
    ptr->block = NULL;
    ptr->currentSize = 10;
    ptr->top = 0;
}


bool push(stack *ptr, int n)
{
    if(ptr->top == ptr->currentSize)
    {
        if(ptr->currentSize != ptr->maxSize)
        {
            ptr->currentSize *= 2;
            ptr->block = (int *)realloc(ptr->block, ptr->currentSize * sizeof(int));
        }
        else return false;
    }
    ptr->block[ptr->top] = n;
    ++(ptr->top);
    return true;
}


int size(stack *ptr)
{
    if(!ptr->block) return -1;
    return ptr->top;
}

bool isEmpty(stack *ptr)
{
    return ptr->top == 0;
}


int pop(stack *ptr)
{
    if(isEmpty(ptr)) abort();//return 0;
    int toReturn = ptr->block[ptr->top - 1];
    --ptr->top;
    if(ptr->top < ptr->currentSize / 2 && ptr->currentSize > 10)
    {
        ptr->currentSize >>= 1;
        ptr->block = (int *)realloc(ptr->block, ptr->currentSize * sizeof(int));
    }
    return toReturn;
}


void clear(stack *ptr)
{
    ptr->currentSize = 10;
    ptr->top = 0;
    ptr->block = (int *)realloc(ptr->block, ptr->currentSize);
}
