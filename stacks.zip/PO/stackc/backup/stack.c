#include "stack.h"
#include <stdlib.h>



bool stackInit(stack *ptr)
{
    ptr->maxSize = 160;
    ptr->currentSize = 10;
    ptr->top = 0;
    ptr->block = (int *)malloc(ptr->currentSize * sizeof(int));
    if(ptr->block) return true;
    return false;
}

void stackDestroy(stack *ptr)
{
    free(ptr->block);
    ptr->currentSize = 10;
    ptr->top = 0;
}


bool push(stack *ptr, int n)
{
    if(ptr->top == ptr->currentSize - 1)
    {
        if(ptr->currentSize != ptr->maxSize)
        {
            ptr->currentSize <<= 1;
            ptr->block = (int *)realloc(ptr->block, ptr->currentSize);
        }
        else return false;
    }
    ptr->block[ptr->top] = n;
    ++(ptr->top);

    return true;
}


int size(stack *ptr)
{
    return ptr->top;
}

bool isEmpty(stack *ptr)
{
    return ptr->top;
}


int pop(stack *ptr)
{
    if(isEmpty(ptr)) return 0;
    int toReturn = ptr->top;
    --ptr->top;
    if(ptr->top < ptr->currentSize / 2 && ptr->currentSize > 10)
    {
        ptr->currentSize >>= 1;
        ptr->block = (int *)realloc(ptr->block, ptr->currentSize);
    }
    return toReturn;
}


void clear(stack *ptr)
{
    ptr->currentSize = 10;
    ptr->top = 0;
    ptr->block = (int *)realloc(ptr->block, ptr->currentSize);
}
