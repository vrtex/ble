#include <stdlib.h>
#include <stdio.h>
#include "stack.h"

int main()
{
    stack s1, s2;
    stackInit(&s1);
    stackInit(&s2);
    int i;
    for(i = 0; i < 160; ++i)
    {
        push(&s1, i);
        push(&s2, i);
        printf("%d\n", size(&s1));
        printf("%d\n", size(&s2));
    }
    clear(&s2);
    while (!isEmpty(&s1))
    {
        printf("%d\n", pop(&s1));
    }
    stackDestroy(&s1);
    stackDestroy(&s2);
    return 0;
}
